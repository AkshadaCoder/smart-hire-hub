package com.jsp.ojpms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

	@GetMapping("/login")
	public String loginPage() {
	    return "login";
	}

	@GetMapping("/register")
	public String registerPage() {
	    return "register";
	}

	@GetMapping("/home")
	public String homePage() {
	    return "home";
	}

	@GetMapping("/reset")
	public String resetPage() {
	    return "reset";
	}

}
